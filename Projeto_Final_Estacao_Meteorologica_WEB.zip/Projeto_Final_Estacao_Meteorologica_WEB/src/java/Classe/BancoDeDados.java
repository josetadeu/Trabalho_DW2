package Classe;

import static java.awt.SystemColor.window;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Platform;
import javax.swing.JOptionPane;
/**
 *
 * @author tadeualdrigue
 */
public class BancoDeDados {
    
    private static final BancoDeDados instancia = new BancoDeDados();
    private final String nomeDoBanco;
    private final String login;
    private final String senha;
    private final String host;

    private BancoDeDados() {
	/*
	 Trecho de código usado para "Registrar" o driver da JDBC na JVM. 
	 Idealmente, é executado apenas uma vez, como é o caso aqui.
	 */
	try {
	    Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Banco 1");
	} catch (ClassNotFoundException e) {
	    System.out.println(e.getMessage());
	}
	/*
	 Definições das informações de conexão do banco de dados.
	 */
	this.nomeDoBanco = "estacao_meteorologica";
	this.login = "root";
	this.senha = "257842";
	this.host = "localhost";
    }
    
    public static BancoDeDados getInstance() {
	return instancia;
    }
        
    /*
     Método usado para retornar uma conexão válida ao nosso banco de dados.
     */
    private Connection conectar() throws SQLException {
        System.out.println("Conectando...");
	Connection conexao = DriverManager.getConnection("jdbc:mysql://" + host + "/" + nomeDoBanco, login, senha);
	return conexao;
    }

    /*
     Método utilizado para cadastrar um novo usuário
     */
    public void inserirUsuario(String login, String senha, String email) {
	try {
            System.out.println("Inserindo");
	    /*
	     Cria a conexao para o mySQL.
	     */
	    Connection conexao = this.conectar();

	    /*
	     Cria o "template" da query para inserir uma pessoa.
	     */
            PreparedStatement stm = conexao.prepareStatement("INSERT INTO usuarios(id,login,senha,email) VALUES(null,?,?,?)");
	    /*
	     Insere os parâmetros na ordem adequada, preenchendo a query
	     */
	    stm.setString(1, login);
	    stm.setString(2, senha);
	    stm.setString(3, email);

	    /*
	     Executa a query e não recebe nenhum resultado.
	     */
	    stm.executeUpdate();

	    /*
	     É necessário fechar o "template" da query e a conexão (IMPORTANTE!)
	     */
	    stm.close();
	    conexao.close();
            System.out.println("Usuário inserido com sucesso!");
            JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Atenção: " + "Alerta", JOptionPane.INFORMATION_MESSAGE);
	} catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Erro ao inserir...", "Atenção: " + "Erro!", JOptionPane.INFORMATION_MESSAGE);
	}
    }

    /*
     Método utilizado para realizar o login de um usuário
     */
    public boolean loginUsuario(String login, String senha) {
	boolean logado = false;
	try {
            System.out.println("LoginUsuario");
	    Connection conexao = this.conectar();

	    PreparedStatement stm = conexao.prepareStatement("SELECT senha FROM usuarios WHERE login = ?");
	    stm.setString(1, login);

	    ResultSet resultado = stm.executeQuery();

	    String senhaBD = null;
	    while (resultado.next()) {
		senhaBD = resultado.getString("senha");
	    }
	    if (senhaBD != null && senhaBD.equals(senha)) {
		logado = true;
	    }
	    resultado.close();
	    stm.close();
	    conexao.close();
	} catch (Exception e) {
	}
	return logado;
    }
}
