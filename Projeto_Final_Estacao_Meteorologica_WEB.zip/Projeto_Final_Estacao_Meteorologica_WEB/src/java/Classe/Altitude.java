package Classe;

import java.sql.Date;

/**
 *
 * @author tadeualdrigue
 */
public class Altitude {
    private int codigo;
    private Float valor;
    Date data;
    
    public Altitude(){
        
    }
    
    public Altitude(int codigo, Float valor, Date data) {
        this.codigo = codigo;
        this.valor = valor;
        this.data = data;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Float getValor() {
        return valor;
    }

    public void setValor(Float valor) {
        this.valor = valor;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
    
}
