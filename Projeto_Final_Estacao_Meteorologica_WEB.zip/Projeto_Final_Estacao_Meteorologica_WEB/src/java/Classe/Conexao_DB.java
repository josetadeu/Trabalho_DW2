package Classe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author tadeualdrigue
 */
public class Conexao_DB {
    private Connection con;
    
    public Conexao_DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/estacao_meteorologica","root","257842"); 
        }
        catch(ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
    }

    public Conexao_DB(Connection con) {
        this.con = con;
    }
    
    public ResultSet executarQuery(String qry) throws SQLException{
       
        Statement stmt;
        
        stmt = con.createStatement();
        
        return stmt.executeQuery(qry);
    }
    
    public void alterar(String qry) throws SQLException{
        Statement stmt = con.createStatement();
        
        stmt.executeUpdate(qry);
    }
}
