package Servlet;

import Classe.BancoDeDados;
import java.io.IOException;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author tadeualdrigue
 */
@WebServlet(name = "Servlet_Cadastrar_Pessoa", urlPatterns = {"/Servlet_Cadastrar_Pessoa","/cadastrar"})
public class Servlet_Cadastrar_Pessoa extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    /*
	Recebe os parâmetros do usuário
	*/
	Map<String,String[]> param = request.getParameterMap();
	
	/*
	Gera a senha criptografada, efetivamente ofuscando a senha no banco de dados.
	*/
	String senhaCriptografada = request.getParameter("senha");
        System.out.println("senha: "+senhaCriptografada);
	//senhaCriptografada = DigestUtils.md5Hex((String)param.get("senha")[0]);
	
	/*
	Realiza o cadastro do usuário 
	*/
	BancoDeDados.getInstance().inserirUsuario(param.get("login")[0],
		senhaCriptografada, param.get("email")[0]);
	
	/*
	Redireciona o usuário para a página inicial
	*/
	response.sendRedirect("index.html");
    }    
    


}
