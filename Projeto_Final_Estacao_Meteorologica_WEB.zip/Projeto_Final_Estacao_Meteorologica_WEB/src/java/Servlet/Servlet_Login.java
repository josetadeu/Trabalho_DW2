package Servlet;

import Classe.BancoDeDados;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author tadeualdrigue
 */
@WebServlet(name = "Servlet_Login", urlPatterns = {"/Servlet_Login","/login"})
public class Servlet_Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /*
	 Recebe os parâmetros do usuário
	 */
	Map<String, String[]> param = request.getParameterMap();
        
	/*
	 Verifica se o login e senha enviadas correspondem a um usuário no banco de dados.
	 */
	boolean logado = BancoDeDados.getInstance().loginUsuario(param.get("login")[0], param.get("senha")[0]);
    System.out.println("logado: "+ logado);
	if (logado) {
            System.out.println("logado!!!");
	    /*
	     Corresponde! Encaminha o usuário para uma página "exclusiva".
	    */
	    request.getRequestDispatcher("/WEB-INF/index_Logado.jsp").forward(request, response);
	} else {
	    /*
	     Não corresponde! Redireciona o usuário para a página inicial.
	     */
            System.out.println("Falha ao logar...");
	    response.sendRedirect("index.html");
	}
    }

 
}
