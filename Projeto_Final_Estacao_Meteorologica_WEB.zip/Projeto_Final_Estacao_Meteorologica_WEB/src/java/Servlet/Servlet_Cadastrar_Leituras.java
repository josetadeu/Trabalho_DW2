package Servlet;

import Classe.BancoDeDados;
import java.io.IOException;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author tadeualdrigue
 */
@WebServlet(name = "Servlet_Cadastrar_Leituras", urlPatterns = {"/Servlet_Cadastrar_Leituras"})
public class Servlet_Cadastrar_Leituras extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /*
	Recebe os parâmetros do usuário
	*/
	Map<String,String[]> param = request.getParameterMap();
	
	String senha = request.getParameter("senha");
        System.out.println("senha: "+senha);
	
	/*
	Realiza o cadastro do usuário 
	*/
	BancoDeDados.getInstance().inserirUsuario(param.get("login")[0],
		senha, param.get("email")[0]);
	
	/*
	Redirecion a o usuário para a página inicial
	*/
	response.sendRedirect("index.html");
    }    

}
