package Servlet;

import Classe.Humidade;
import Classe.Luminosidade;
import Classe.Pessoa;
import Classe.Pressao;
import Classe.Temperatura;
import DAO.HumidadeDAO;
import DAO.LuminosidadeDAO;
import DAO.PessoaDAO;
import DAO.PressaoDAO;
import DAO.TemperaturaDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author tadeualdrigue
 */
@WebServlet(name = "Servlet_Estacao_Meteorologica", urlPatterns = {"/index.html","/Servlet_Estacao_Meteorologica"})
public class Servlet_Estacao_Meteorologica extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
        HttpSession session = request.getSession();
        
        ArrayList<Temperatura> temperaturas;
        ArrayList<Humidade> humidades;
        ArrayList<Luminosidade> luminosidades;
        ArrayList<Pressao> pressoes;
        
        ArrayList<Pessoa> pessoas;
        String humidade;
            
        if(session.getAttribute("temperaturas") == null){
            System.out.println("temperaturas == null");
            temperaturas = new TemperaturaDAO().listarTemperatura();
            session.setAttribute("temperaturas", temperaturas);
        }
        
        if(session.getAttribute("humidades") == null){
            System.out.println("humidades == null");
            humidades = new HumidadeDAO().listarHumidade();
            humidade = new HumidadeDAO().humidade_Online();
            session.setAttribute("humidades", humidades);
        }
        
        if(session.getAttribute("luminosidades") == null){
            System.out.println("luminosidades == null");
            luminosidades = new LuminosidadeDAO().listarLuminosidade();
            session.setAttribute("luminosidades", luminosidades);
        }
        
        if(session.getAttribute("pressoes") == null){
            System.out.println("pressoes == null");
            pressoes = new PressaoDAO().listarPressao();
            session.setAttribute("pressoes", pressoes);
        }
          
       if(session.getAttribute("pessoas") == null){
            System.out.println("pessoas == null");
            pessoas = new PessoaDAO().listarPessoa();
            session.setAttribute("pessoas", pessoas);
        }
        
        if(request.getParameter("mostrar")!= null){
            System.out.println("mostrar != null: " + request.getParameter("mostrar"));
            session.setAttribute("mostrar", request.getParameter("mostrar"));
            response.sendRedirect("./");
            return;
        }
 
        if(session.getAttribute("mostrar") == null){
            System.out.println("mostrar != null: " + request.getParameter("mostrar"));
            System.out.println("mostrar == null");
            request.getRequestDispatcher("WEB-INF/index.jsp").forward(request, response);
            return;
        }

        String mostrar=(String)session.getAttribute("mostrar");
        
        switch(mostrar){
            case "temperatura":
                System.out.println("Temperatura...");
                request.getRequestDispatcher("WEB-INF/listar_Temperatura.jsp").forward(request,response);
            break;
                
            case "humidade":
                System.out.println("Humidade...");
                request.getRequestDispatcher("WEB-INF/listar_Humidade.jsp").forward(request,response);
                System.out.println("Humidade Fim...");
            break;
 
            case "luminosidade":
                System.out.println("Luminosidade...");
                request.getRequestDispatcher("WEB-INF/listar_Luminosidade.jsp").forward(request,response);
            break;
                       
            case "pressao":
                System.out.println("Pressao...");
                request.getRequestDispatcher("WEB-INF/listar_Pressao.jsp").forward(request,response);
            break;
                
            case "login":
                System.out.println("Login...");
                request.getRequestDispatcher("WEB-INF/login.jsp").forward(request,response);
            break;
                
            case "editar_Leitura":
                System.out.println("Editar Leitura...");
                request.getRequestDispatcher("WEB-INF/index_Logado.jsp").forward(request,response);
            break;
                
            case "cadastrar":
                System.out.println("Cadastro...");
                request.getRequestDispatcher("WEB-INF/cadastrar.jsp").forward(request,response);
            break;
                
            case "listar_Usuarios":
                System.out.println("Listar pessoa...#");
                request.getRequestDispatcher("WEB-INF/listar_Pessoa.jsp").forward(request,response);
                System.out.println("Listou pessoa...");
            break;
                
            case "editar_Usuarios":
                System.out.println("Editar...");
                request.getRequestDispatcher("WEB-INF/cadastrar.jsp").forward(request,response);
            break;
                
            default:
        System.out.println("default");
        request.getRequestDispatcher("WEB-INF/index.jsp").forward(request, response);
       
        }

    }
}
