package Servlet;

import DAO.AltitudeDAO;
import DAO.HumidadeDAO;
import DAO.LuminosidadeDAO;
import DAO.PressaoDAO;
import DAO.TemperaturaDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author tadeualdrigue
 */
@WebServlet(name = "Servlet_Coleta_Online", urlPatterns = {"/Servlet_Coleta_Online"})
public class Servlet_Coleta_Online extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
            String param = (String) request.getParameter("botao_1");
            System.out.println("Parametro: "+param);  
            
            if(param == "buscar_Temperatura"){
                String temp = new TemperaturaDAO().temperatura_Online();
            } 
             
            if(param == "buscar_Humidade"){
                String humid = new HumidadeDAO().humidade_Online();
            }
            
            if(param == "buscar_Pressao"){
                String press = new PressaoDAO().pressao_Online();
            }
            
            if(param == "buscar_Altitude"){
                String altitud = new AltitudeDAO().altitude_Online();
            }
            
            if(param == "buscar_Luminosidade"){
                String luminosidad = new LuminosidadeDAO().luminosidade_Online();
            }

    }

}
