package DAO;

import Classe.Conexao_DB;
import Classe.Humidade;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author tadeualdrigue
 */
public class HumidadeDAO {
    Conexao_DB connDB;
    
    public HumidadeDAO() {
            connDB = new Conexao_DB();
        }

        public HumidadeDAO(Conexao_DB connDB) {
            this.connDB = connDB;
        }
        
        public ArrayList<Humidade> listarHumidade(){
            ArrayList<Humidade> humidades = new ArrayList<>();

            try{
                System.out.println("Iniciando listar humidade...");
                ResultSet rs = connDB.executarQuery("SELECT * FROM humidade");

                while(rs.next()){
                    humidades.add(new Humidade(rs.getInt(1),
                                               rs.getFloat(2),
                                               rs.getDate(3))
                                 );
                        
                }
                System.out.println("Listado humidade");
            }
            
            catch(SQLException e){
                System.out.println("Falha na aquisicao de dados");
                e.printStackTrace();
            }

            return humidades;
        }
        
        public String humidade_Online(){
            
        String Humidade = null;

        try{
        System.out.println("Buscando...");

        Document html = Jsoup.connect("http://177.180.165.158:1300/").get();
        String title = html.title();
        Humidade = html.body().getElementsByTag("h4").text();
        
        System.out.println("Humidade$: " + Humidade);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return Humidade;
    }
}
