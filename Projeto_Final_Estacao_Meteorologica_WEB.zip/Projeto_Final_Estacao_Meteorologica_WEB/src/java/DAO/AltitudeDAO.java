package DAO;

import Classe.Altitude;
import Classe.Conexao_DB;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author tadeualdrigue
 */
public class AltitudeDAO {
    Conexao_DB connDB;
    
    public AltitudeDAO() {
            connDB = new Conexao_DB();
        }

        public AltitudeDAO(Conexao_DB connDB) {
            this.connDB = connDB;
        }
        
        public ArrayList<Altitude> listarAltitude(){
            ArrayList<Altitude> altitudes = new ArrayList<>();

            try{
                System.out.println("Iniciando listar altitude...");
                ResultSet rs = connDB.executarQuery("SELECT * FROM altitude");

                while(rs.next()){
                    altitudes.add(new Altitude(rs.getInt(1),
                                               rs.getFloat(2),
                                               rs.getDate(3))
                                 );
                        
                }
                System.out.println("Listado altitude");
            }
            
            catch(SQLException e){
                System.out.println("Falha na aquisicao de dados");
                e.printStackTrace();
            }

            return altitudes;
        }
        
        public String altitude_Online(){
            
        String Altitude = null;

        try{
        System.out.println("Buscando...");

        Document html = Jsoup.connect("http://177.180.165.158:1300/").get();
        String title = html.title();
        Altitude = html.body().getElementsByTag("h6").text();
        
        System.out.println("Altitude: " + Altitude);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return Altitude;
    }
}
