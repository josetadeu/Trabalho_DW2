package DAO;

import Classe.Conexao_DB;
import Classe.Temperatura;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author tadeualdrigue
 */
public class TemperaturaDAO {
    Conexao_DB connDB;
    
    public TemperaturaDAO() {
            connDB = new Conexao_DB();
    }

    public TemperaturaDAO(Conexao_DB connDB) {
        this.connDB = connDB;
    }
        
    public ArrayList<Temperatura> listarTemperatura(){
        ArrayList<Temperatura> temperaturas = new ArrayList<>();

        try{
            System.out.println("Iniciando listar temperatura...");
            ResultSet rs = connDB.executarQuery("SELECT * FROM temperatura");

            while(rs.next()){
                temperaturas.add(new Temperatura(rs.getInt(1),
                                                 rs.getFloat(2),
                                                 rs.getDate(3))
                                );
            }
            System.out.println("Listado temperatura...");
                
        }
            
        catch(SQLException e){
            System.out.println("Falha na aquisicao de dados");
            e.printStackTrace();
        }
            
        return temperaturas;
    }
        
    public String temperatura_Online(){
            
        String temperatura = null;

        try{
        System.out.println("Buscando...");

        Document html = Jsoup.connect("http://177.180.165.158:1300/").get();
        String title = html.title();
        temperatura = html.body().getElementsByTag("h3").text();
        
        System.out.println("Temperatura$: " + temperatura);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return temperatura;
    }
        
}
