package DAO;

import Classe.Conexao_DB;
import Classe.Luminosidade;
import Classe.Temperatura;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author tadeualdrigue
 */
public class LuminosidadeDAO {
    Conexao_DB connDB;
    
    public LuminosidadeDAO() {
            connDB = new Conexao_DB();
        }

        public LuminosidadeDAO(Conexao_DB connDB) {
            this.connDB = connDB;
        }
        
        public ArrayList<Luminosidade> listarLuminosidade(){
            ArrayList<Luminosidade> luminosidades = new ArrayList<>();

            try{
                System.out.println("Iniciando listar luminosidade...");
                ResultSet rs = connDB.executarQuery("SELECT * FROM luminosidade");

                while(rs.next()){
                    luminosidades.add(new Luminosidade(rs.getInt(1),
                                                     rs.getFloat(2),
                                                     rs.getDate(3))
                                    );
                }
                System.out.println("Listado luminosidade...");
            }
            
            catch(SQLException e){
                System.out.println("Falha na aquisicao de dados");
                e.printStackTrace();
            }
            
            return luminosidades;
        }
        
        public String luminosidade_Online(){
            
        String Luminosidade = null;

        try{
        System.out.println("Buscando..."); 

        Document html = Jsoup.connect("http://177.180.165.158:1300/").get();
        String title = html.title();
        Luminosidade = html.body().getElementsByTag("h7").text();
        
        System.out.println("Luminosidade$: " + Luminosidade);
        }   
        catch (IOException e) {
            e.printStackTrace();
        }
        return Luminosidade;
    }
}
