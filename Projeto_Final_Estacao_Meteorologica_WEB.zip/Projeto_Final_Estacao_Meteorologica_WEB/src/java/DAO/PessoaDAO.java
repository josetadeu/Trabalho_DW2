package DAO;

import Classe.Conexao_DB;
import Classe.Pessoa;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author tadeualdrigue
 */
public class PessoaDAO {
    Conexao_DB connDB;
    
    public PessoaDAO() {
            connDB = new Conexao_DB();
        }

        public PessoaDAO(Conexao_DB connDB) {
            this.connDB = connDB;
        }
        
        public ArrayList<Pessoa> listarPessoa(){
            ArrayList<Pessoa> pessoas = new ArrayList<>();

            try{
                System.out.println("Iniciando listar pessoas...");
                ResultSet rs = connDB.executarQuery("SELECT * FROM usuarios");

                while(rs.next()){
                    pessoas.add(new Pessoa(rs.getInt(1),
                                           rs.getString(2),
                                           rs.getString(3),
                                           rs.getString(4))
                                 );
                }
                System.out.println("Pessoas listadas com sucesso");
            }
            
            catch(SQLException e){
                System.out.println("Falha na aquisicao de dados");
                e.printStackTrace();
            }
            
            return pessoas;
        }

}
