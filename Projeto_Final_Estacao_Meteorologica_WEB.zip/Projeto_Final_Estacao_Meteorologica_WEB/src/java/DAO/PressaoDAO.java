package DAO;

import Classe.Conexao_DB;
import Classe.Luminosidade;
import Classe.Pressao;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author tadeualdrigue
 */
public class PressaoDAO {
    Conexao_DB connDB;
    
    public PressaoDAO() {
            connDB = new Conexao_DB();
        }

        public PressaoDAO(Conexao_DB connDB) {
            this.connDB = connDB;
        }
        
        public ArrayList<Pressao> listarPressao(){
            ArrayList<Pressao> pressoes = new ArrayList<>();

            try{
                System.out.println("Iniciando listar pressao...");
                ResultSet rs = connDB.executarQuery("SELECT * FROM pressao");

                while(rs.next()){
                    pressoes.add(new Pressao(rs.getInt(1),
                                             rs.getFloat(2),
                                             rs.getDate(3))
                                    );
                }
                System.out.println("Listado pressao...");
            }
            
            catch(SQLException e){
                System.out.println("Falha na aquisicao de dados");
                e.printStackTrace();
            }
            
            return pressoes;
        }
        
        public String pressao_Online(){
            
        String Pressao = null;

        try{
        System.out.println("Buscando...");

        Document html = Jsoup.connect("http://177.180.165.158:1300/").get();
        String title = html.title();
        Pressao = html.body().getElementsByTag("h5").text();
        
        System.out.println("Pressao$: " + Pressao);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return Pressao;
    }
}
